import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Transactions extends JFrame{
    private JButton customersButton;
    private JButton accountsButton;
    private JButton transactionsButton;
    private JTable transactionsTable;
    private JButton button1;
    private JPanel mainPanell;
    private JPanel transactionsMainPanel;


    // Method to load CSV data into JTable using BufferedReader
    public void load_table() {
        String csvFile = "transactions.csv";  // Replace with your CSV file path
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line = br.readLine(); // Read the first line (headers)

            if (line != null) {
                String[] headers = line.split(","); // Split by comma to get headers

                // Initialize the table model with headers
                DefaultTableModel tableModel = new DefaultTableModel(headers, 0);

                // Read the remaining lines (rows)
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");  // Split by comma to get row data
                    tableModel.addRow(data);  // Add each row to the table model
                }
                // Set the table model to the JTable
                transactionsTable.setModel(tableModel);
            }
        } catch (IOException e) {
            System.out.println(" ");
        }
    }


    public Transactions() {
        customersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCustomerGUI cr = new createCustomerGUI();
                cr.load_table();
                cr.setContentPane(cr.getCreateCustomerPanel());
                cr.setVisible(true);
                cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                cr.setMinimumSize(new Dimension(500,500));
                cr.setTitle("CREATE CUSTOMER");
                cr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                cr.setIconImage(icon);
                Transactions.this.dispose();

            }
        });
        accountsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAccountGUI op = new openAccountGUI();
                op.setContentPane(op.getOpenAccountMainPanel());
                op.setVisible(true);
                op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                op.setMinimumSize(new Dimension(500,500));
                op.setTitle("OPEN ACCOUNT");
                op.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                op.setIconImage(icon);
                Transactions.this.dispose();
                op.load_table();
            }
        });
        transactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Transactions tr = new Transactions();
                tr.load_table();
                tr.setContentPane(tr.transactionsMainPanel);
                tr.setVisible(true);
                tr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                tr.setMinimumSize(new Dimension(500,500));
                tr.setTitle("VIEW TRANSACTIONS");
                tr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                tr.setIconImage(icon);

            }
        });
    }

    public JPanel getMainPanell(){
        return transactionsMainPanel;
    }

//    public static void main(String[] args) {
//        Transactions tr = new Transactions();
//        tr.load_table();
//        tr.setContentPane(tr.transactionsMainPanel);
//        tr.setVisible(true);
//        tr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        tr.setMinimumSize(new Dimension(500,500));
//        tr.setTitle("VIEW TRANSACTIONS");
//        tr.setLocationRelativeTo(null);
//        Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
//        tr.setIconImage(icon);
//    }
}
