import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class withDrawMoneyGUI extends JFrame{
    private JLabel withDrawLabel;
    private JTextField accountNumberTextField;
    private JTextField withdrawalAmountTextField;
    private JLabel accountNumberLable;
    private JLabel amountLable;
    private JPanel withdrawaPanelLable;
    private JPanel withdrawMainPanel;
    private JButton withdrawBtn;
    private JPanel menuPanell;
    private JButton customersButton;
    private JButton accountsButton;
    private JButton transactionsButton;


    createCustomerGUI cr = new createCustomerGUI();

    public withDrawMoneyGUI() {
        withdrawBtn.addActionListener(new ActionListener() {
            @Override

            public void actionPerformed(ActionEvent e) {
                String accountNumber = accountNumberTextField.getText().trim();
                double amount;
                try {
                    amount = Double.parseDouble(withdrawalAmountTextField.getText().trim());

                    // Perform withdrawal using the updated method
                    if (Main.withdrawMoney(accountNumber, amount)) {
                        JOptionPane.showMessageDialog(null, "Withdrawal successful!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Insufficient funds or account not found.");
                    }
//                    cr.updateCSVFile();

                    // Log the transaction using the Account class method
                    Logger.logAction("Withdrawal attempt: AccountNumber = " + accountNumber + ", Amount = " + amount);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid withdrawal amount.");
                }
            }
        });
        customersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCustomerGUI cr = new createCustomerGUI();
                cr.load_table();
                cr.setContentPane(cr.getCreateCustomerPanel());
                cr.setVisible(true);
                cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                cr.setMinimumSize(new Dimension(500,500));
                cr.setTitle("CREATE CUSTOMER");
                cr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                cr.setIconImage(icon);
                withDrawMoneyGUI.this.dispose();
            }
        });
        accountsButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                openAccountGUI op = new openAccountGUI();
                op.setContentPane(op.getOpenAccountMainPanel());
                op.setVisible(true);
                op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                op.setMinimumSize(new Dimension(500,500));
                op.setTitle("OPEN ACCOUNT");
                op.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                op.setIconImage(icon);
                withDrawMoneyGUI.this.dispose();
                op.load_table();
            }
        });
        transactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Transactions tr = new Transactions();
                tr.load_table();
                tr.setContentPane(tr.getMainPanell());
                tr.setVisible(true);
                tr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                tr.setMinimumSize(new Dimension(500,500));
                tr.setTitle("VIEW TRANSACTIONS");
                tr.setLocationRelativeTo(null);
                withDrawMoneyGUI.this.dispose();
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                tr.setIconImage(icon);
            }
        });
    }
//public void WithdrawMoneyGUI() {
//    withdrawBtn.addActionListener(new ActionListener() {
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            String accountNumber = accountNumberTextField.getText().trim();
//            double amount;
//            try {
//                amount = Double.parseDouble(withdrawalAmountTextField.getText().trim());
//
//                // Perform withdrawal using the updated method
//                if (Main.withdrawMoney(accountNumber, amount)) {
//                    JOptionPane.showMessageDialog(null, "Withdrawal successful!");
//                } else {
//                    JOptionPane.showMessageDialog(null, "Insufficient funds or account not found.");
//                }
//
//            } catch (NumberFormatException ex) {
//                JOptionPane.showMessageDialog(null, "Please enter a valid withdrawal amount.");
//            }
//        }
//    });
//}

    public JPanel getWithdrawMainPanel() {
        return withdrawMainPanel;
    }


//    public static void main(String[] args) {
//        withDrawMoneyGUI wd = new withDrawMoneyGUI();
//        wd.setContentPane(wd.withdrawMainPanel);
//        wd.setVisible(true);
//        wd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        wd.setMinimumSize(new Dimension(500,500));
//        wd.setTitle("CREATE CUSTOMER");
//        wd.setLocationRelativeTo(null);
//        Image icon = Toolkit.getDefaultToolkit().getImage(withDrawMoneyGUI.class.getResource("/icons/bank.png"));
//        wd.setIconImage(icon);
//    }

}
