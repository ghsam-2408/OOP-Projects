import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CustomerDataLoader {
    private Map<String, Customer> customerMap = new HashMap<>();

    // Load customers from CSV file
    public void loadCustomersFromCSV(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                String customerID = fields[0].trim();
                String name = fields[1].trim();
                String address = fields[2].trim();
                Customer customer = new Customer(customerID, name, address);
                customerMap.put(customerID, customer); // Store customer by ID
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Map<String, Customer> getCustomerMap() {
        return customerMap;
    }
}
