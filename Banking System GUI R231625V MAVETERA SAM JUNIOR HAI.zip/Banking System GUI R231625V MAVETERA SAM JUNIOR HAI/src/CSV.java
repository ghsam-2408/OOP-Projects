import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class CSV {

    // Method to write headers to the CSV file if it doesn't exist
    public static void writeHeaders(String filename, String headers) {
        if (!Files.exists(Paths.get(filename))) { // Check if file exists
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                writer.write(headers);
                writer.newLine(); // Move to the next line
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to write data to the CSV file
    public static void writeToCSV(String filename, String data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) { // Append mode
            writer.write(data);
            writer.newLine(); // Move to the next line
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    public static void updateAccountInCSV(String accountNumber, String number, double newBalance) {
//        String filePath = "accounts.csv";  // Specify the CSV file to be updated
//        ArrayList<Object> accountData = new ArrayList<>(); // Stores all rows from the CSV file
//        boolean accountFound = false;
//
//        // Step 1: Read all data from the accounts.csv file and store it in memory
//        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
//            String line;
//            while ((line = br.readLine()) != null) {
//                String[] values = line.split(",");
//                if (values[0].equals(accountNumber)) {
//                    // Update the balance for the matching account number
//                    values[2] = String.valueOf(newBalance); // Assuming balance is in the 3rd column (index 2)
//                    accountFound = true;
//                }
//                accountData.add(values); // Add the row to the list
//            }
//        } catch (IOException e) {
//            System.out.println("Error reading from accounts.csv: " + e.getMessage());
//        }
//
//        // Step 2: If the account was found, write the updated data back to accounts.csv
//        if (accountFound) {
//            try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
//                for (Object accountRow : accountData) {
//                    bw.write(String.join((CharSequence) ",", (CharSequence) accountRow));
//                    bw.newLine();
//                }
//                System.out.println("Account updated successfully.");
//            } catch (IOException e) {
//                System.out.println("Error writing to accounts.csv: " + e.getMessage());
//            }
//        } else {
//            System.out.println("Account number " + accountNumber + " not found in accounts.csv.");
//        }
//    }

    public static void updateAccountInCSV(String accountNumber, double newBalance) {
        String filePath = "accounts.csv";  // Specify the CSV file to be updated
        ArrayList<Object> accountData = new ArrayList<>(); // Stores all rows from the CSV file
        boolean accountFound = false;

        // Step 1: Read all data from the accounts.csv file and store it in memory
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // Ensure both accountNumber and values[0] are trimmed and compared in a case-insensitive manner
                if (values[0].trim().equalsIgnoreCase(accountNumber.trim())) {
                    // Update the balance for the matching account number
                    values[2] = String.valueOf(newBalance); // Assuming balance is in the 3rd column (index 2)
                    accountFound = true;
                }
                accountData.add(values); // Add the row to the list
            }
        } catch (IOException e) {
            System.out.println("Error reading from accounts.csv: " + e.getMessage());
        }

        // Step 2: If the account was found, write the updated data back to accounts.csv
        if (accountFound) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
                for (Object accountRow : accountData) {
                    bw.write(String.join((CharSequence) ",", (CharSequence) accountRow));
                    bw.newLine();
                }
                System.out.println("Account updated successfully.");
            } catch (IOException e) {
                System.out.println("Error writing to accounts.csv: " + e.getMessage());
            }
        } else {
            System.out.println("Account number " + accountNumber + " not found in accounts.csv.");
        }
    }

    public static Account loadAccountFromCSV(String accountNumber) {
        try (BufferedReader br = new BufferedReader(new FileReader("accounts.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");

                // Assume the CSV columns are in the following order: AccountNumber, CustomerID, Balance, AccountType
                String csvAccountNumber = values[0].trim();
                String customerID = values[1].trim();
                double balance = Double.parseDouble(values[2].trim());
                String accountType = values[3].trim(); // This should be the account type

                // Compare account numbers to find a match
                if (csvAccountNumber.equalsIgnoreCase(accountNumber.trim())) {
                    // Validate the account type here
                    switch (accountType.toLowerCase()) {
                        case "savings":
                            return new SavingsAccount(csvAccountNumber, customerID, balance);
                        case "current":
                            return new CurrentAccount(csvAccountNumber, customerID, balance);
                        case "loan":
                            return new LoanAccount(csvAccountNumber, customerID, balance);
                        default:
                            System.out.println("Unknown account type found in CSV: " + accountType);
                            return null;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading account data from CSV: " + e.getMessage());
        }
        return null; // Return null if the account is not found
    }



}
