import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class depositMoneyGUI extends JFrame{
    private JPanel depositMoneyMainPanel;
    private JLabel depositMoneyIcon;
    private JLabel customerIDLable;
    private JTextField customerIdtextField;
    private JTextField accountNumberTextField;
    private JTextField depositAmountTextField;
    private JButton depositNowButton;
    private JButton customersButton;
    private JButton accountsButton;
    private JButton transactionsButton;


    public depositMoneyGUI() {
        depositNowButton.addActionListener(new ActionListener() {
            @Override
//            public void actionPerformed(ActionEvent e) {
//                // Capture user input from text fields
//                String customerID = customerIdtextField.getText().trim();
//                String accountNumber = accountNumberTextField.getText().trim();
//                String depositAmountStr = depositAmountTextField.getText().trim();
//
//                // Validate the input
//                if (customerID.isEmpty() || accountNumber.isEmpty() || depositAmountStr.isEmpty()) {
//                    JOptionPane.showMessageDialog(null, "Please fill all fields.");
//                    return;
//                }
//
//                try {
//                    double amount = Double.parseDouble(depositAmountStr); // Convert deposit amount to double
//                    if (amount <= 0) {
//                        JOptionPane.showMessageDialog(null, "Please enter a valid deposit amount.");
//                        return;
//                    }
//
//                    // Call the deposit logic
//                    if (depositMoney(customerID, accountNumber, amount)) {
//                        JOptionPane.showMessageDialog(null, "Deposit successful!");
//                    } else {
//                        JOptionPane.showMessageDialog(null, "Deposit failed. Check account details.");
//                    }
//
//                } catch (NumberFormatException ex) {
//                    JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
//                }
//            }

            public void actionPerformed(ActionEvent e) {
                // Capture user input from text fields
                String customerID = customerIdtextField.getText().trim();
                String accountNumber = accountNumberTextField.getText().trim();
                String depositAmountStr = depositAmountTextField.getText().trim();

                // Validate the input
                if (customerID.isEmpty() || accountNumber.isEmpty() || depositAmountStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all fields.");
                    return;
                }

                try {
                    double amount = Double.parseDouble(depositAmountStr); // Convert deposit amount to double
                    if (amount <= 0) {
                        JOptionPane.showMessageDialog(null, "Please enter a valid deposit amount.");
                        return;
                    }

                    // Load the account from accounts.csv using the account number
                    Account account = CSV.loadAccountFromCSV(accountNumber);

                    // Check if the account exists and belongs to the customerID provided
                    if (account != null && account.customerID.equals(customerID)) {
                        // Perform the deposit
                        account.deposit(amount);
                        // Update the account with the new balance in the CSV
                        CSV.updateAccountInCSV(account.getAccountNumber(), account.getBalance());
                        JOptionPane.showMessageDialog(null, "Deposit successful!");

                    } else {
                        // Either the account was not found, or the customer ID does not match the account holder
                        JOptionPane.showMessageDialog(null, "Account not found or Customer ID does not match.");
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
                }
            }

        });
        transactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Transactions tr = new Transactions();
                tr.load_table();
                tr.setContentPane(tr.getMainPanell());
                tr.setVisible(true);
                tr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                tr.setMinimumSize(new Dimension(500,500));
                tr.setTitle("VIEW TRANSACTIONS");
                tr.setLocationRelativeTo(null);
                depositMoneyGUI.this.dispose();
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                tr.setIconImage(icon);
            }

        });
        customersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCustomerGUI cr = new createCustomerGUI();
                cr.load_table();
                cr.setContentPane(cr.getCreateCustomerPanel());
                cr.setVisible(true);
                cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                cr.setMinimumSize(new Dimension(500,500));
                cr.setTitle("CREATE CUSTOMER");
                cr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                cr.setIconImage(icon);
                depositMoneyGUI.this.dispose();
            }
        });
        accountsButton.addComponentListener(new ComponentAdapter() {
        });
        accountsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAccountGUI op = new openAccountGUI();
                op.setContentPane(op.getOpenAccountMainPanel());
                op.setVisible(true);
                op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                op.setMinimumSize(new Dimension(500,500));
                op.setTitle("OPEN ACCOUNT");
                op.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                op.setIconImage(icon);
                depositMoneyGUI.this.dispose();
                op.load_table();
            }
        });
    }

    public JPanel getDepositMoneyMainPanel(){
        return depositMoneyMainPanel;
    }

    // Logic for depositing money
    private boolean depositMoney(String customerID, String accountNumber, double amount) {
        // Retrieve accounts for the given customer ID
        ArrayList<String> accountNumbers = getAccountsByCustomerId(customerID);

        if (accountNumbers.isEmpty()) {
            Logger.logAction("No accounts found for Customer ID: " + customerID);
            return false; // No accounts found
        }

        // Ensure the selected account belongs to the customer
        if (!accountNumbers.contains(accountNumber)) {
            Logger.logAction("Account number " + accountNumber + " not found for Customer ID: " + customerID);
            return false; // Account not found for this customer
        }

        // Find the account and deposit money
        Account account = Main.bank.findAccountByNumber(accountNumber);
        if (account != null) {
            account.deposit(amount); // Deposit the amount
            Logger.logAction("Deposit: AccountNumber = " + accountNumber + ", Amount = " + amount);
            CSV.updateAccountInCSV("accounts.csv", account.getBalance()); // Update CSV with new balance
            return true; // Deposit successful
        } else {
            Logger.logAction("Account not found for deposit: AccountNumber = " + accountNumber);
            return false; // Account not found
        }
    }

    // Helper method to retrieve account numbers by customer ID from the CSV
    private static ArrayList<String> getAccountsByCustomerId(String customerID) {
        ArrayList<String> accountNumbers = new ArrayList<>();

        // Read accounts from accounts.csv
        try (BufferedReader br = new BufferedReader(new FileReader("accounts.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 1 && values[1].equals(customerID)) {
                    accountNumbers.add(values[0]); // Add account number to the list
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading from accounts.csv: " + e.getMessage());
        }

        return accountNumbers;
    }



//    public static void main(String[] args) {
//        depositMoneyGUI dp = new depositMoneyGUI();
//        dp.setContentPane(dp.depositMoneyMainPanel);
//        dp.setVisible(true);
//        dp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        dp.setMinimumSize(new Dimension(500,500));
//        dp.setTitle("DEPOSIT MONEY");
//        dp.setLocationRelativeTo(null);
//        Image icon = Toolkit.getDefaultToolkit().getImage(depositMoneyGUI.class.getResource("/icons/bank.png"));
//        dp.setIconImage(icon);
//    }
}
