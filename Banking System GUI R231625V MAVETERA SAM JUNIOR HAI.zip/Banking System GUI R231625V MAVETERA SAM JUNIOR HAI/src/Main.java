

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    static final Bank bank = new Bank("Dooer");

    public static void main(String[] args) {

        createCustomerGUI cr = new createCustomerGUI();
        cr.setContentPane(cr.getCreateCustomerPanel());
        cr.setVisible(true);
        cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cr.setMinimumSize(new Dimension(500,500));
        cr.setTitle("CREATE CUSTOMER");
        cr.setLocationRelativeTo(null);
        Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
        cr.setIconImage(icon);
        cr.load_table();
    }

    private static int lastCustomerID = 1000;

    public static void createCustomer(String name, String address) {
        String customerID;
        customerID = String.valueOf(lastCustomerID);
        customerID = getUniqueCustomerId(customerID);

//        Customer newCustomer = new Customer(customerID, name, address);
//        bank.addCustomer(newCustomer);


        Customer newCustomer = new Customer(customerID, name, address);
        bank.addCustomer(newCustomer);
        JOptionPane.showMessageDialog(null, "Customer created successfully with account number: " + newCustomer.getCustomerID(), "Success", JOptionPane.INFORMATION_MESSAGE);

        Logger.logAction("Customer created: ID = " + customerID + ", Name = " + name + ", Address = " + address);
        CSV.writeToCSV("customers.csv", customerID + "," + name + "," + address);
    }


    private static String getUniqueCustomerId(String baseID) {
        ArrayList<String> existingIds = new ArrayList<>();

        // Read existing customer IDs from the CSV file
        try (BufferedReader br = new BufferedReader(new FileReader("customers.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 0) {
                    existingIds.add(values[0]);
                }
            }
        } catch (IOException e) {
            System.out.println("k");
        }

        while (existingIds.contains(baseID)) {
            baseID = String.valueOf(++lastCustomerID);
        }

        return baseID;
    }


    public static void openAccount(Map<String, Customer> customerMap, String customerID, String accountType, double initialDeposit, Double optionalParam1, Double optionalParam2) {

        Customer customer = customerMap.get(customerID);

        if (customer != null) {
            Account newAccount;
            switch (accountType.toLowerCase()) {
                case "savings":
                    // Use the optionalParam1 for savings rate
                    if (optionalParam1 != null) {
                        newAccount = new SavingsAccount(accountType, customer, initialDeposit, optionalParam1);
                    } else {
                        JOptionPane.showMessageDialog(null, "Savings rate is required.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    break;
                case "current":
                    // Use the optionalParam1 for overdraft limit
                    if (optionalParam1 != null) {
                        newAccount = new CurrentAccount(accountType, customer, initialDeposit, optionalParam1);
                    } else {
                        JOptionPane.showMessageDialog(null, "Overdraft limit is required.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    break;
                case "loan":
                    // Use optionalParam1 for loan amount and optionalParam2 for loan rate
                    if (optionalParam1 != null && optionalParam2 != null) {
                        newAccount = new LoanAccount(accountType, customer, optionalParam1, optionalParam2);
                    } else {
                        JOptionPane.showMessageDialog(null, "Both loan amount and interest rate are required.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    break;
                default:
                    Logger.logAction("Invalid account type entered: " + accountType);
                    JOptionPane.showMessageDialog(null, "Invalid account type.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
            }

            bank.openAccount(customer, newAccount);
            customer.openAccount(newAccount);
            JOptionPane.showMessageDialog(null, "Account opened successfully with account number: " + newAccount.getAccountNumber(), "Success", JOptionPane.INFORMATION_MESSAGE);
            Logger.logAction("Account opened: CustomerID = " + customerID + ", AccountType = " + accountType + ", InitialDeposit = " + initialDeposit);

            // Ensure the headers are written only once
            CSV.writeHeaders("accounts.csv", "Account Number,CustomerID,InitialDeposit,AccountType");
            CSV.writeToCSV("accounts.csv", newAccount.getAccountNumber() + "," + customerID + "," + initialDeposit + "," + accountType);
        } else {
            Logger.logAction("Customer not found with ID: " + customerID);
            JOptionPane.showMessageDialog(null, "Customer not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private static ArrayList<String> getAccountsByCustomerId(String customerID) {
        ArrayList<String> accountNumbers = new ArrayList<>();

        // Read accounts from accounts.csv
        try (BufferedReader br = new BufferedReader(new FileReader("accounts.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 1 && values[1].equals(customerID)) {
                    accountNumbers.add(values[0]);
                }
            }
        } catch (IOException e) {
//            System.out.println("Error reading from accounts.csv: ");
        }

        return accountNumbers;
    }

    public static boolean withdrawMoney(String accountNumber, double amount) {
        // Load accounts from CSV to find the account by number
        Account account = Account.loadAccountFromCSV(accountNumber);


        if (account != null) {
            if (account.getBalance() >= amount) { // Assuming getBalance() method exists
                account.setBalance(account.getBalance() - amount); // Deduct amount from balance

                updateAccCSVFile(accountNumber, account.getBalance());
//                System.out.println("Withdrawal successful!");
                Logger.logAction("Withdrawal: AccountNumber = " + accountNumber + ", Amount = " + amount);

                // Log the transaction to the transactions.csv
                Account.logTransaction("withdrawal", amount);
                return true; // Withdrawal successful
            } else {
//                System.out.println("Insufficient funds.");
                Logger.logAction("Withdrawal failed due to insufficient funds: AccountNumber = " + accountNumber + ", Amount = " + amount);
                return false; // Insufficient funds
            }
        } else {
            System.out.println("Account not found.");
            Logger.logAction("Account not found for withdrawal: AccountNumber = " + accountNumber);
            return false; // Account not found
        }
    }

    // Method to update the CSV file
    private static void updateAccCSVFile(String accountNumber, double newBalance) {
        String csvFile = "accounts.csv";  // Path to your accounts CSV file
        ArrayList<Object> accountsList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            boolean accountFound = false;

            // Read the CSV file and update the balance for the specific account
            while ((line = br.readLine()) != null) {
                String[] accountData = line.split(","); // Assuming CSV values are comma-separated
                if (accountData[0].equals(accountNumber)) { // Assuming the first column is the account number
                    accountData[1] = String.valueOf(newBalance); // Update balance (assuming it's the second column)
                    accountFound = true;
                }
                accountsList.add(accountData); // Store the current line (whether modified or not)
            }

            // If the account was found, write back the updated accounts to the CSV file
            if (accountFound) {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(csvFile))) {
                    for (Object accountData : accountsList) {
                        bw.write(String.join(",", (CharSequence) accountData));
                        bw.newLine();
                    }
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error updating accounts CSV file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void checkBalance() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        Account account = bank.findAccountByNumber(accountNumber);

        if (account != null) {
//            System.out.println("Balance for account " + accountNumber + ": " + account.getBalance());
            Logger.logAction("Balance check: AccountNumber = " + accountNumber + ", Balance = " + account.getBalance());
        } else {
            Logger.logAction("Account not found for balance check: AccountNumber = " + accountNumber);
//            System.out.println("Account not found.");
        }
    }

    private static void viewTransactionHistory() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        // display transaction history from the file (to be implemented)
        Logger.logAction("Transaction history requested for account: " + accountNumber);
        System.out.println("Transaction history for account " + accountNumber + " (to be implemented).");
    }

    private static void repayLoan() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter repayment amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        Account account = bank.findAccountByNumber(accountNumber);
        if (account instanceof LoanAccount) {
            ((LoanAccount) account).repayLoan(amount);
//            System.out.println("Loan repayment successful!");
            Logger.logAction("Loan repayment: AccountNumber = " + accountNumber + ", Amount = " + amount);
        } else {
            Logger.logAction("Loan account not found for repayment: AccountNumber = " + accountNumber);
//            System.out.println("Loan account not found.");
        }
    }
}
