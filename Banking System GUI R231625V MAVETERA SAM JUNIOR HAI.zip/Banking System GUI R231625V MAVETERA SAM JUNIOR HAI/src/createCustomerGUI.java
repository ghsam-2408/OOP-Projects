import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;


public class createCustomerGUI extends JFrame{
    private JLabel createCustomerLable;
    private JLabel customerIcon;
    private JLabel nameLable;
    private JTextField nameTextField;
    private JLabel addressLable;
    private JTextField addressTextField;
    private JButton createCustomerBtn;
    private JPanel createCustomerPanel;
    private JLabel openAccountLable;
    private JButton openAccountButton;
    private JTable customersTable;
    private JButton deleteButton;
    private JButton customersButton;
    private JButton accountsButton;
    private JButton transactionsButton;
    private JPanel menuPanel;


    // Method to load CSV data into JTable using BufferedReader
    public void load_table() {
        String csvFile = "customers.csv";  // Replace with your CSV file path
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line = br.readLine(); // Read the first line (headers)

            if (line != null) {
                String[] headers = line.split(","); // Split by comma to get headers

                // Initialize the table model with headers
                DefaultTableModel tableModel = new DefaultTableModel(headers, 0);

                // Read the remaining lines (rows)
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");  // Split by comma to get row data
                    tableModel.addRow(data);  // Add each row to the table model
                }

                // Set the table model to the JTable
                customersTable.setModel(tableModel);
            }
        } catch (IOException e) {
            System.out.println(" ");
        }
    }

    // Method to update the CSV file
    public void updateCSVFile() {
        String csvFile = "customers.csv";  // Replace with your actual CSV file path

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(csvFile))) {
            // Write the headers back to the CSV file
            for (int i = 0; i < customersTable.getColumnCount(); i++) {
                bw.write(customersTable.getColumnName(i));
                if (i < customersTable.getColumnCount() - 1) {
                    bw.write(","); // Add comma between headers
                }
            }
            bw.newLine(); // Move to the next line

            // Write remaining rows to the CSV file
            for (int i = 0; i < customersTable.getRowCount(); i++) {
                for (int j = 0; j < customersTable.getColumnCount(); j++) {
                    bw.write(customersTable.getValueAt(i, j).toString());
                    if (j < customersTable.getColumnCount() - 1) {
                        bw.write(","); // Add comma between values
                    }
                }
                bw.newLine(); // Move to the next line for the next row
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(createCustomerGUI.this, "Error updating CSV file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    public createCustomerGUI() {
        createCustomerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameTextField.getText();
                String address = addressTextField.getText();

                if (name.isEmpty() || address.isEmpty()) {
                    JOptionPane.showMessageDialog(createCustomerGUI.this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                else {
                    Main.createCustomer(name, address);
                }

//                JOptionPane.showMessageDialog(createCustomerGUI.this, "Customer created successfully! Customer ID: "+  , "Success", JOptionPane.INFORMATION_MESSAGE);
                nameTextField.setText("");
                addressTextField.setText("");
                nameTextField.requestFocusInWindow();
                load_table();

            }
        });
        openAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAccountGUI op = new openAccountGUI();
                op.setContentPane(op.getOpenAccountMainPanel());
                op.setVisible(true);
                op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                op.setMinimumSize(new Dimension(500,500));
                op.setTitle("OPEN ACCOUNT");
                op.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                op.setIconImage(icon);
                createCustomerGUI.this.dispose();
                op.load_table();
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultTableModel tableModel = (DefaultTableModel) customersTable.getModel();
                int selectedRow = customersTable.getSelectedRow();

                if (selectedRow == -1) { // Check if no row is selected
                    if (customersTable.getRowCount() == 0) {
                        JOptionPane.showMessageDialog(createCustomerGUI.this, "The Table is empty", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(createCustomerGUI.this, "No record selected", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    // Remove the selected row from the table model
                    tableModel.removeRow(selectedRow);

                    // Update the CSV file after deletion
                    updateCSVFile();
                }
                JOptionPane.showMessageDialog(createCustomerGUI.this, "Customer record Deleted successfully","Success", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        customersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCustomerGUI cr = new createCustomerGUI();
                cr.load_table();
                cr.setContentPane(cr.createCustomerPanel);
                cr.setVisible(true);
                cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                cr.setMinimumSize(new Dimension(500,500));
                cr.setTitle("CREATE CUSTOMER");
                cr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                cr.setIconImage(icon);
                createCustomerGUI.this.dispose();
            }
        });
        accountsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAccountGUI op = new openAccountGUI();
                op.setContentPane(op.getOpenAccountMainPanel());
                op.setVisible(true);
                op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                op.setMinimumSize(new Dimension(500,500));
                op.setTitle("OPEN ACCOUNT");
                op.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                op.setIconImage(icon);
                createCustomerGUI.this.dispose();
                op.load_table();
            }
        });
        transactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Transactions tr = new Transactions();
                tr.load_table();
                tr.setContentPane(tr.getMainPanell());
                tr.setVisible(true);
                tr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                tr.setMinimumSize(new Dimension(500,500));
                tr.setTitle("VIEW TRANSACTIONS");
                tr.setLocationRelativeTo(null);
                createCustomerGUI.this.dispose();
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                tr.setIconImage(icon);
            }
        });
    }

    public JPanel getCreateCustomerPanel(){
        return createCustomerPanel;
    }

//    public static void main(String[] args) {
//        createCustomerGUI cr = new createCustomerGUI();
//        cr.load_table();
//        cr.setContentPane(cr.createCustomerPanel);
//        cr.setVisible(true);
//        cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        cr.setMinimumSize(new Dimension(500,500));
//        cr.setTitle("CREATE CUSTOMER");
//        cr.setLocationRelativeTo(null);
//        Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
//        cr.setIconImage(icon);
//    }
}
