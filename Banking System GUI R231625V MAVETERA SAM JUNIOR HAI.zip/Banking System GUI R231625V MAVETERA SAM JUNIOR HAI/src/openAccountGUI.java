import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

public class openAccountGUI extends JFrame{
    private JLabel openAccountLable;
    private JLabel openAccountIcon;
    private JTextField customerIdTextField;
    private JLabel customerIdLable;
    private JLabel initialDepositLabel;
    private JTextField initialDepositTextField;
    private JComboBox accountTypeComboBox;
    private JLabel accountTypeLabel;
    private JButton openAccountBtn;
    private JPanel openAccountMainPanel;
    private JLabel notyetcustomerLabel;
    private JButton createCustomerButton;
    private JTable openAccountTable;
    private JButton depositButton;
    private JButton withDrawButton;
    private JPanel menuPanell;
    private JButton customersButton;
    private JButton accountsButton;
    private JButton transactionsButton;
    private Map<String, Customer> customerMap;

    // Method to load CSV data into JTable using BufferedReader
    void load_table() {
        String csvFile = "accounts.csv";  // Replace with your CSV file path
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line = br.readLine(); // Read the first line (headers)

            if (line != null) {
                String[] headers = line.split(","); // Split by comma to get headers

                // Initialize the table model with headers
                DefaultTableModel tableModel = new DefaultTableModel(headers, 0);

                // Read the remaining lines (rows)
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");  // Split by comma to get row data
                    tableModel.addRow(data);  // Add each row to the table model
                }

                // Set the table model to the JTable
                openAccountTable.setModel(tableModel);
            }
        } catch (IOException e) {
            System.out.println("Error loading CSV: " + e.getMessage());
        }
    }


    public openAccountGUI() {

        // Load customer data from CSV
        CustomerDataLoader customerDataLoader = new CustomerDataLoader();
        customerDataLoader.loadCustomersFromCSV("customers.csv"); // Specify your CSV file path
        customerMap = customerDataLoader.getCustomerMap(); // Get the loaded customers


        openAccountBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String customerID = customerIdTextField.getText().trim();
                String accountType = (String) accountTypeComboBox.getSelectedItem();
                String initialDepositString = initialDepositTextField.getText().trim();

                // Check if any fields are empty
                if (customerID.isEmpty() || initialDepositString.isEmpty() || accountType == null) {
                    JOptionPane.showMessageDialog(openAccountGUI.this, "Please fill out all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Exit the method if any field is empty
                }

                // Validate initial deposit input
                double initialDeposit;
                try {
                    initialDeposit = Double.parseDouble(initialDepositString);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter a valid initial deposit.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Exit the method if input is invalid
                }

                Double optionalParam1 = null; // For interest rate, overdraft limit, or loan amount
                Double optionalParam2 = null; // For loan rate if account type is loan

                // Validate additional parameters based on account type
                switch (accountType.toLowerCase()) {
                    case "savings":
                        String savingsRateString = JOptionPane.showInputDialog(openAccountGUI.this, "Enter interest rate:");
                        if (savingsRateString == null || savingsRateString.trim().isEmpty()) {
                            JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter a savings interest rate.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        try {
                            optionalParam1 = Double.parseDouble(savingsRateString);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter a valid savings interest rate.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        break;
                    case "current":
                        String overdraftLimitString = JOptionPane.showInputDialog(openAccountGUI.this, "Enter overdraft limit:");
                        if (overdraftLimitString == null || overdraftLimitString.trim().isEmpty()) {
                            JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter an overdraft limit.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        try {
                            optionalParam1 = Double.parseDouble(overdraftLimitString);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter a valid overdraft limit.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        break;
                    case "loan":
                        String loanAmountString = JOptionPane.showInputDialog(openAccountGUI.this, "Enter loan amount:");
                        String loanRateString = JOptionPane.showInputDialog(openAccountGUI.this, "Enter interest rate:");
                        if (loanAmountString == null || loanAmountString.trim().isEmpty() || loanRateString == null || loanRateString.trim().isEmpty()) {
                            JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter both loan amount and interest rate.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        try {
                            optionalParam1 = Double.parseDouble(loanAmountString);
                            optionalParam2 = Double.parseDouble(loanRateString);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(openAccountGUI.this, "Please enter valid loan amount and interest rate.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        break;
                    default:
                        JOptionPane.showMessageDialog(openAccountGUI.this, "Invalid account type selected.", "Error", JOptionPane.ERROR_MESSAGE);
                        return; // Exit if account type is invalid

                }

                // Proceed to open account
                Main.openAccount(customerMap, customerID, accountType, initialDeposit, optionalParam1, optionalParam2);
            }

        });
        createCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCustomerGUI cr = new createCustomerGUI();
                cr.load_table();
                cr.setContentPane(cr.getCreateCustomerPanel());
                cr.setVisible(true);
                cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                cr.setMinimumSize(new Dimension(500,500));
                cr.setTitle("CREATE CUSTOMER");
                cr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                cr.setIconImage(icon);
                openAccountGUI.this.dispose();
            }
        });
        withDrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                withDrawMoneyGUI wd = new withDrawMoneyGUI();
                wd.setContentPane(wd.getWithdrawMainPanel());
                wd.setVisible(true);
                wd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                wd.setMinimumSize(new Dimension(500,500));
                wd.setTitle("CREATE CUSTOMER");
                wd.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(withDrawMoneyGUI.class.getResource("/icons/bank.png"));
                wd.setIconImage(icon);
                openAccountGUI.this.dispose();
            }
        });
        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                depositMoneyGUI dp = new depositMoneyGUI();
                dp.setContentPane(dp.getDepositMoneyMainPanel());
                dp.setVisible(true);
                dp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                dp.setMinimumSize(new Dimension(500,500));
                dp.setTitle("DEPOSIT MONEY");
                dp.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(depositMoneyGUI.class.getResource("/icons/bank.png"));
                dp.setIconImage(icon);
                openAccountGUI.this.dispose();
            }
        });
        customersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCustomerGUI cr = new createCustomerGUI();
                cr.load_table();
                cr.setContentPane(cr.getCreateCustomerPanel());
                cr.setVisible(true);
                cr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                cr.setMinimumSize(new Dimension(500,500));
                cr.setTitle("CREATE CUSTOMER");
                cr.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                cr.setIconImage(icon);
                openAccountGUI.this.dispose();
            }
        });
        accountsButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                openAccountGUI op = new openAccountGUI();
                op.setContentPane(op.getOpenAccountMainPanel());
                op.setVisible(true);
                op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                op.setMinimumSize(new Dimension(500,500));
                op.setTitle("OPEN ACCOUNT");
                op.setLocationRelativeTo(null);
                Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
                op.setIconImage(icon);
                openAccountGUI.this.dispose();
                op.load_table();
            }
        });
        transactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Transactions tr = new Transactions();
                tr.load_table();
                tr.setContentPane(tr.getMainPanell());
                tr.setVisible(true);
                tr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                tr.setMinimumSize(new Dimension(500,500));
                tr.setTitle("VIEW TRANSACTIONS");
                tr.setLocationRelativeTo(null);
                openAccountGUI.this.dispose();
                Image icon = Toolkit.getDefaultToolkit().getImage(createCustomerGUI.class.getResource("/icons/bank.png"));
                tr.setIconImage(icon);
            }
        });
    }


    public JPanel getOpenAccountMainPanel() {
        return openAccountMainPanel;
    }

//    public static void main(String[] args) {
//        openAccountGUI op = new openAccountGUI();
//        op.load_table();
//        op.setContentPane(op.openAccountMainPanel);
//        op.setVisible(true);
//        op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        op.setMinimumSize(new Dimension(500,500));
//        op.setTitle("OPEN ACCOUNT");
//        op.setLocationRelativeTo(null);
//        Image icon = Toolkit.getDefaultToolkit().getImage(openAccountGUI.class.getResource("/icons/bank.png"));
//        op.setIconImage(icon);
//
//    }

}
