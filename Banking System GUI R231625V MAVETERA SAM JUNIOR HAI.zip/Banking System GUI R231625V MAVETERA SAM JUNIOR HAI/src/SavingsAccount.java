
public class SavingsAccount extends Account {
    private static final String customerID = "";
    private double interestRate;


    public SavingsAccount(String accountNumber, Customer accountHolder, double initialDeposit, double interestRate) {
        super(accountNumber, customerID, initialDeposit);
        this.interestRate = interestRate;
    }

//    public SavingsAccount( ,  ,  ) {
//        super();
//    }

    public SavingsAccount(String accountNumber, String customerID, double balance) {

        super(accountNumber, customerID, balance);
    }

    @Override
    public void applyInterest() {
        double interest = balance * interestRate / 100;
        balance += interest;
        logTransaction("Interest Applied", interest);
        System.out.println("Applied interest of " + interest + ". New balance: " + balance);
    }


//    @Override
//    public void logTransaction(String type, double amount) {
//        System.out.println("Transaction logged: " + type + " of amount " + amount);
//        // Here, you can add the transaction to the bank's transaction log (not shown here)
//    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
}

