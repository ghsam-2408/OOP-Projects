
import java.util.Date;
import java.util.Random;
import java.io.*;
import java.util.*;

public abstract class Account {
    protected static String accountNumber;
    protected double balance;
    protected Customer accountHolder;
    public String customerID;

    static Scanner scanner = new Scanner(System.in);


    // Constructor and other methods for Account
    public Account(String accountType, String customerID, double balance) {
        this.accountNumber = accountNumber;
        this.customerID = customerID;
        this.balance = balance;
        accountNumber = generateAccountNumber(accountType);
        CSV.writeHeaders("transactions.csv", "TransactionID,AccountNumber,TransactionType,Amount,Date");
    }


    public void setBalance(double balance) {
        this.balance = balance;
    }

//    public static String generateAccountNumber(String accountType) {
//        Random random = new Random();
//
//        char randomLetter = (char) ('A' + random.nextInt(26));
//
//        int randomNumber = random.nextInt(9000) + 1000;
//
//        String prefix;
//        switch (accountType.toLowerCase()) {
//            case "savings":
//                prefix = "S";
//                break;
//            case "current":
//                prefix = "C";
//                break;
//            case "loan":
//                prefix = "L";
//                break;
//            default:
//                throw new IllegalArgumentException("Invalid account type: " + accountType);
//        }
//
//
//        return prefix + "-" + randomLetter + "-" + randomNumber;
//    }


    public static String generateAccountNumber(String accountType) {
        Random random = new Random();

        // Validate the account type before proceeding
        String prefix;
        switch (accountType.toLowerCase()) {
            case "savings":
                prefix = "S";
                break;
            case "current":
                prefix = "C";
                break;
            case "loan":
                prefix = "L";
                break;
            default:
                throw new IllegalArgumentException("Invalid account type: " + accountType); // Only throw for account types, not account numbers
        }

        char randomLetter = (char) ('A' + random.nextInt(26)); // Random letter generation
        int randomNumber = random.nextInt(9000) + 1000;        // 4-digit random number

        return prefix + "-" + randomLetter + "-" + randomNumber;
    }



    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            logTransaction("Deposit", amount);
            System.out.println("Deposited " + amount + " into account " + accountNumber);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }


    private static int transactionId = 1100;

    public static boolean withdrawMoney(String accountNumber, double amount) {
        // Load accounts from CSV to find the account by number
        Account account = loadAccountFromCSV(accountNumber);

        if (account != null) {
            if (account.getBalance() >= amount) { // Assuming getBalance() method exists
                account.setBalance(account.getBalance() - amount); // Deduct amount from balance
                System.out.println("Withdrawal successful!");
                Logger.logAction("Withdrawal: AccountNumber = " + accountNumber + ", Amount = " + amount);

                // Log the transaction to the transactions.csv
                logTransaction("withdrawal", amount);
                return true; // Withdrawal successful
            } else {
                System.out.println("Insufficient funds.");
                Logger.logAction("Withdrawal failed due to insufficient funds: AccountNumber = " + accountNumber + ", Amount = " + amount);
                return false; // Insufficient funds
            }
        } else {
            System.out.println("Account not found.");
            Logger.logAction("Account not found for withdrawal: AccountNumber = " + accountNumber);
            return false; // Account not found
        }
    }


    public static Account loadAccountFromCSV(String accountNumber) {
        try (BufferedReader br = new BufferedReader(new FileReader("accounts.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                // Ensure both values are trimmed and compared exactly
                if (values[0].trim().equalsIgnoreCase(accountNumber.trim())) {
                    String customerID = values[1].trim();
                    double balance = Double.parseDouble(values[2].trim());
                    String accountType = values[3].trim();

                    // Return the correct type of account
                    switch (accountType.toLowerCase()) {
                        case "savings":
                            return new SavingsAccount(accountNumber, customerID, balance);
                        case "current":
                            return new CurrentAccount(accountNumber, customerID, balance);
                        case "loan":
                            return new LoanAccount(accountNumber, customerID, balance);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading account data: " + e.getMessage());
        }
        return null;
    }


    private static String generateTransactionID() {
        return String.valueOf(++transactionId);
    }

    // Non-static logTransaction method to record transactions
    protected static void logTransaction(String type, double amount) {
        String transactionID = generateTransactionID();
        Date date = new Date();
        String filename = "transactions.csv";
        String data = String.join(",", transactionID, accountNumber, type, String.valueOf(amount), date.toString());

        // Assuming CSV.writeToCSV() is a utility method to write to a CSV file
        CSV.writeToCSV(filename, data);
    }


    public abstract void applyInterest();


    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public Customer getAccountHolder() {
        return accountHolder;
    }

}
