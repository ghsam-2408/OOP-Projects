//import java.io.*;
//import java.util.ArrayList;
//import java.util.List;
//
//public class AccountsDataLoader {
//
//    // Method to load accounts from CSV
//    public List<Account> loadAccountsFromCSV(String filePath) {
//        List<Account> accounts = new ArrayList<>();
//        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
//            String line;
//            while ((line = br.readLine()) != null) {
//                String[] fields = line.split(",");
//                String accountNumber = fields[0].trim();
//                String customerID = fields[1].trim();
//                double balance = Double.parseDouble(fields[2].trim());
//                String accountType = fields[3].trim();
//
//                // Create Account object based on the account type
//                Account account;
//                switch (accountType.toLowerCase()) {
//                    case "savings":
//                        account = new SavingsAccount(accountNumber, customerID, balance); // Adjust interest rate as needed
//                        break;
//                    case "current":
//                        account = new CurrentAccount(accountNumber, customerID, balance); // Adjust overdraft limit as needed
//                        break;
//                    case "loan":
//                        account = new LoanAccount(accountNumber, customerID, balance); // Adjust loan interest rate as needed
//                        break;
//                    default:
//                        continue; // Skip if the account type is invalid
//                }
//
//                accounts.add(account); // Add account to the list
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return accounts;
//    }
//
//    // Method to find an account by its account number
//    static Account findAccountByNumber(String accountNumber, List<Account> accounts) {
//        for (Account account : accounts) {
//            if (account.getAccountNumber().equals(accountNumber)) {
//                return account;
//            }
//        }
//        return null;
//    }
//
//    // Method to save accounts to a CSV file
//    static void saveAccountsToCSV(String filePath, List<Account> accounts) {
//        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
//            for (Account account : accounts) {
//                String line = account.getAccountNumber() + "," + account.getCustomerID() + "," + account.getBalance() + "," + account.getAccountType();
//                bw.write(line);
//                bw.newLine();
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
