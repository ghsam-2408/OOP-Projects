
import java.util.ArrayList;

public class Customer {
    public String customerID;
    public String name;
    public String address;
    public ArrayList<Account> accounts;

    public Customer(String customerID, String name, String address) {
        this.customerID = customerID;
        this.name = name;
        this.address = address;
        this.accounts = new ArrayList<>();

        // Create CSV file with headers
        CSV.writeHeaders("customers.csv", "CustomerID,Name,Address");
    }


    public void openAccount(Account account) {
        accounts.add(account);
        System.out.println("Account " + account.getAccountNumber() + " opened for customer " + name);
    }


    public Account getAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        System.out.println("Account with number " + accountNumber + " not found.");
        return null;
    }


//    public void transferFunds(String fromAccountNumber, String toAccountNumber, double amount) {
//        Account fromAccount = getAccount(fromAccountNumber);
//        Account toAccount = getAccount(toAccountNumber);
//
//        if (fromAccount != null && toAccount != null) {
//            if (fromAccount.getBalance() >= amount) {
//                Account.withdrawMoney(amount);
//                toAccount.deposit(amount);
//                System.out.println("Transferred " + amount + " from account " + fromAccountNumber + " to account " + toAccountNumber);
//            } else {
//                System.out.println("Insufficient funds in account " + fromAccountNumber);
//            }
//        }
//    }

    public void calculateMonthlyInterest() {
        for (Account account : accounts) {
            account.applyInterest();
        }
    }


    public String getCustomerID() {
        return customerID;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }

    private void logCustomerToCSV() {
        String filename = "customers.csv";
        String data = String.join(",", customerID, name, address);
        CSV.writeToCSV(filename, data);
    }
}
