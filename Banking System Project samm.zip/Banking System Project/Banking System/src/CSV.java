import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CSV {

    // Method to write headers to the CSV file if it doesn't exist
    public static void writeHeaders(String filename, String headers) {
        if (!Files.exists(Paths.get(filename))) { // Check if file exists
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                writer.write(headers);
                writer.newLine(); // Move to the next line
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to write data to the CSV file
    public static void writeToCSV(String filename, String data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) { // Append mode
            writer.write(data);
            writer.newLine(); // Move to the next line
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
