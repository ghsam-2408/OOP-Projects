import java.util.Date;
import java.util.Random;

public abstract class Account {
    protected String accountNumber;
    protected double balance;
    protected Customer accountHolder;

    public Account(String accountType, Customer accountHolder, double initialDeposit) {
        this.accountNumber = generateAccountNumber(accountType); // Generate account number with {A-Z}-{4 digits} format
        this.accountHolder = accountHolder;
        this.balance = initialDeposit;

        // Creating CSV file with headers
        CSV.writeHeaders("transactions.csv", "TransactionID,AccountNumber,TransactionType,Amount,Date");
    }

    public static String generateAccountNumber(String accountType) {
        Random random = new Random();


        char randomLetter = (char) ('A' + random.nextInt(26));

        int randomNumber = random.nextInt(9000) + 1000;

        String prefix;
        switch (accountType.toLowerCase()) {
            case "savings":
                prefix = "S";
                break;
            case "current":
                prefix = "C";
                break;
            case "loan":
                prefix = "L";
                break;
            default:
                throw new IllegalArgumentException("Invalid account type: " + accountType);
        }


        return prefix + "-" + randomLetter + "-" + randomNumber;
    }


    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            logTransaction("Deposit", amount);
            System.out.println("Deposited " + amount + " into account " + accountNumber);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }


    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            logTransaction("Withdrawal", amount);
            System.out.println("Withdrew " + amount + " from account " + accountNumber);
        } else {
            System.out.println("Insufficient balance or invalid withdrawal amount.");
        }
    }


    public abstract void applyInterest();


    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public Customer getAccountHolder() {
        return accountHolder;
    }


    private static int transactionId = 0000;
    private String generateTransactionID() {
        String transactionID = String.valueOf(++transactionId);
        return transactionID;
    }

    protected void logTransaction(String type, double amount) {
        String transactionID = generateTransactionID();
        Date date = new Date();
        String filename = "transactions.csv";
        String data = String.join(",", transactionID, this.accountNumber , String.valueOf(amount), date.toString());
        CSV.writeToCSV(filename, data);
    }
}
