import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class Logger {
    public static void logAction(String action) {
        try {
            FileWriter logWriter = new FileWriter("major_system_log.txt", true);
            // Get current date and time
            LocalDateTime currentDateTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedDateTime = currentDateTime.format(formatter);

            // Log entry with date and time
            logWriter.write("[" + formattedDateTime + "] " + action + "\n");
            logWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred while logging: " + e.getMessage());
        }
    }
}
