
import java.util.Date;

public class Transaction {
    private final String transactionID;
    private final String accountNumber;
    private final String transactionType;
    private final double amount;
    private final Date date;

    public Transaction(String transactionID, String accountNumber, String transactionType, double amount, Date date) {
        this.transactionID = transactionID;
        this.accountNumber = accountNumber;
        this.transactionType = transactionType;
        this.amount = amount;
        this.date = date;

        logTransactionToCSV();
    }

    public String getTransactionID() {
        return transactionID;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public double getAmount() {
        return amount;
    }

    public Date getDate() {
        return date;
    }

    public void displayTransaction() {
        System.out.println("Transaction ID: " + transactionID);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Transaction Type: " + transactionType);
        System.out.println("Amount: " + amount);
        System.out.println("Date: " + date);
    }

    public void logTransactionToCSV() {
        String filename = "transactions.csv"; // File to store transactions
        String data = String.join(",",transactionID, accountNumber,transactionType, amount + ",", date.toString());
        CSV.writeToCSV(filename, data);
    }

    }

