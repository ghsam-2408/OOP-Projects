
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Bank bank = new Bank("Major");

    public static void main(String[] args) {
        int choice;
        do {
            Logger.logAction("System started.");

            System.out.println("\nWelcome To MAJOR Bank");
            System.out.println("NB: Each account number starts with the letter of its type of Account");
            System.out.println("ie, Savings account number starts with an S");
            System.out.println("\n--- Select Your Preferred Choice ---");
            System.out.println("1. Create a new customer");
            System.out.println("2. Open an account");
            System.out.println("3. Deposit money into an account");
            System.out.println("4. Withdraw money from an account");
            System.out.println("5. Transfer money between accounts");
            System.out.println("6. Check account balance");
            System.out.println("7. View transaction history");
            System.out.println("8. Repay loan");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    createCustomer();
                    break;
                case 2:
                    openAccount();
                    break;
                case 3:
                    depositMoney();
                    break;
                case 4:
                    withdrawMoney();
                    break;
                case 5:
                    transferMoney();
                    break;
                case 6:
                    checkBalance();
                    break;
                case 7:
                    viewTransactionHistory();
                    break;
                case 8:
                    repayLoan();
                    break;
                case 9:
                    Logger.logAction("System exited.");
                    System.out.println("Thank you for using the banking system. Goodbye!");
                    break;
                default:
                    Logger.logAction("Invalid choice entered: " + choice);
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 9);
    }

private static int lastCustomerID = 1000;

    public static void createCustomer() {
        String customerID = String.valueOf(lastCustomerID);
        customerID = getUniqueCustomerId(customerID);

        System.out.print("Enter Customer Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Customer Address: ");
        String address = scanner.nextLine();

        Customer newCustomer = new Customer(customerID, name, address);
        bank.addCustomer(newCustomer);
        System.out.println("Customer created successfully! Customer ID: " + customerID);
        Logger.logAction("Customer created: ID = " + customerID + ", Name = " + name + ", Address = " + address);

        CSV.writeToCSV("customers.csv", customerID + "," + name + "," + address);
    }

    private static String getUniqueCustomerId(String baseID) {
        ArrayList<String> existingIds = new ArrayList<>();

        // Read existing customer IDs from the CSV file
        try (BufferedReader br = new BufferedReader(new FileReader("customers.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 0) {
                    existingIds.add(values[0]);
                }
            }
        } catch (IOException e) {
            System.out.println("Enter your details: ");
        }

        while (existingIds.contains(baseID)) {
            baseID = String.valueOf(++lastCustomerID);
        }

        return baseID;
    }

    public static void openAccount() {
        System.out.print("Enter Customer ID: ");
        String customerID = scanner.nextLine();
        Customer customer = bank.findCustomerById(customerID);

        if (customer != null) {
            System.out.print("Enter account type (Savings/Current/Loan): ");
            String accountType = scanner.nextLine();
            System.out.print("Enter initial deposit amount: ");
            double initialDeposit = scanner.nextDouble();
            scanner.nextLine();

            Account newAccount;
            switch (accountType.toLowerCase()) {
                case "savings":
                    System.out.print("Enter interest rate: ");
                    double savingsRate = scanner.nextDouble();
                    newAccount = new SavingsAccount(accountType, customer, initialDeposit, savingsRate);
                    break;
                case "current":
                    System.out.print("Enter overdraft limit: ");
                    double overdraftLimit = scanner.nextDouble();
                    newAccount = new CurrentAccount(accountType, customer, initialDeposit, overdraftLimit);
                    break;
                case "loan":
                    System.out.print("Enter loan amount: ");
                    double loanAmount = scanner.nextDouble();
                    System.out.print("Enter interest rate: ");
                    double loanRate = scanner.nextDouble();
                    newAccount = new LoanAccount(accountType, customer, loanAmount, loanRate);
                    break;
                default:
                    Logger.logAction("Invalid account type entered: " + accountType);
                    System.out.println("Invalid account type.");
                    return;
            }

            bank.openAccount(customer, newAccount);
            customer.openAccount(newAccount);
            System.out.println("Account opened successfully with account number: " + newAccount.getAccountNumber());
            Logger.logAction("Account opened: CustomerID = " + customerID + ", AccountType = " + accountType + ", InitialDeposit = " + initialDeposit);

            CSV.writeHeaders("accounts.csv", "Account Number,CustomerID,InitialDeposit,AccountType");
            CSV.writeToCSV("accounts.csv", newAccount.getAccountNumber() + "," + customerID + "," + initialDeposit + "," + accountType);
        } else {
            Logger.logAction("Customer not found with ID: " + customerID);
            System.out.println("Customer not found.");
        }
    }

//    private static void depositMoney() {
//        System.out.print("Enter account number: ");
//        String accountNumber = scanner.nextLine();
//        System.out.print("Enter deposit amount: ");
//        double amount = scanner.nextDouble();
//        scanner.nextLine();
//
//        Account account = bank.findAccountByNumber(accountNumber);
//        if (account != null) {
//            account.deposit(amount);
//            System.out.println("Deposit successful!");
//            Logger.logAction("Deposit: AccountNumber = " + accountNumber + ", Amount = " + amount);
//        } else {
//            Logger.logAction("Account not found for deposit: AccountNumber = " + accountNumber);
//            System.out.println("Account not found.");
//        }
//    }

    private static void depositMoney() {
        System.out.print("Enter Customer ID: ");
        String customerID = scanner.nextLine();


        ArrayList<String> accountNumbers = getAccountsByCustomerId(customerID);

        // Check if any accounts were found
        if (accountNumbers.isEmpty()) {
            System.out.println("No accounts found for Customer ID: " + customerID);
            Logger.logAction("No accounts found for Customer ID: " + customerID);
            return; // Exit the method if no accounts found
        }

        // Displaying the found accounts
        System.out.println("Accounts found for Customer ID " + customerID + ":");
        for (int i = 0; i < accountNumbers.size(); i++) {
            System.out.println((i + 1) + ". " + accountNumbers.get(i));
        }

        // Prompting the user to select an account
        System.out.print("Select an account number from above: ");
        int accountChoice = scanner.nextInt();
        scanner.nextLine();

        // Validate the account selection
        if (accountChoice < 1 || accountChoice > accountNumbers.size()) {
            System.out.println("Invalid selection. Please try again.");
            return; //
        }


        String selectedAccountNumber = accountNumbers.get(accountChoice - 1);


        System.out.print("Enter deposit amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        // Find the account by number and perform the deposit
        Account account = bank.findAccountByNumber(selectedAccountNumber);
        if (account != null) {
            account.deposit(amount);
            System.out.println("Deposit successful!");
            Logger.logAction("Deposit: AccountNumber = " + selectedAccountNumber + ", Amount = " + amount);
        } else {
            System.out.println("Account not found.");
        }
    }

    private static ArrayList<String> getAccountsByCustomerId(String customerID) {
        ArrayList<String> accountNumbers = new ArrayList<>();

        // Read accounts from accounts.csv
        try (BufferedReader br = new BufferedReader(new FileReader("accounts.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 1 && values[1].equals(customerID)) {
                    accountNumbers.add(values[0]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading from accounts.csv: ");
        }

        return accountNumbers;
    }


    private static void withdrawMoney() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter withdrawal amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        Account account = bank.findAccountByNumber(accountNumber);
        if (account != null) {
            account.withdraw(amount);
            System.out.println("Withdrawal successful!");
            Logger.logAction("Withdrawal: AccountNumber = " + accountNumber + ", Amount = " + amount);
        } else {
            Logger.logAction("Account not found for withdrawal: AccountNumber = " + accountNumber);
            System.out.println("Account not found.");
        }
    }

    private static void transferMoney() {
        System.out.print("Enter source account number: ");
        String fromAccountNumber = scanner.nextLine();
        System.out.print("Enter destination account number: ");
        String toAccountNumber = scanner.nextLine();
        System.out.print("Enter transfer amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        Account fromAccount = bank.findAccountByNumber(fromAccountNumber);
        Account toAccount = bank.findAccountByNumber(toAccountNumber);

        if (fromAccount != null && toAccount != null && fromAccount.getAccountHolder() == toAccount.getAccountHolder()) {
            fromAccount.withdraw(amount);
            toAccount.deposit(amount);
            System.out.println("Transfer successful!");
            Logger.logAction("Transfer: FromAccount = " + fromAccountNumber + " ToAccount = " + toAccountNumber + ", Amount = " + amount);
        } else {
            Logger.logAction("Transfer failed between accounts: FromAccount = " + fromAccountNumber + " ToAccount = " + toAccountNumber);
            System.out.println("Transfer failed. Ensure both accounts belong to the same customer.");
        }
    }

    private static void checkBalance() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        Account account = bank.findAccountByNumber(accountNumber);

        if (account != null) {
            System.out.println("Balance for account " + accountNumber + ": " + account.getBalance());
            Logger.logAction("Balance check: AccountNumber = " + accountNumber + ", Balance = " + account.getBalance());
        } else {
            Logger.logAction("Account not found for balance check: AccountNumber = " + accountNumber);
            System.out.println("Account not found.");
        }
    }

    private static void viewTransactionHistory() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        // display transaction history from the file (to be implemented)
        Logger.logAction("Transaction history requested for account: " + accountNumber);
        System.out.println("Transaction history for account " + accountNumber + " (to be implemented).");
    }

    private static void repayLoan() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter repayment amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        Account account = bank.findAccountByNumber(accountNumber);
        if (account instanceof LoanAccount) {
            ((LoanAccount) account).repayLoan(amount);
            System.out.println("Loan repayment successful!");
            Logger.logAction("Loan repayment: AccountNumber = " + accountNumber + ", Amount = " + amount);
        } else {
            Logger.logAction("Loan account not found for repayment: AccountNumber = " + accountNumber);
            System.out.println("Loan account not found.");
        }
    }
}
