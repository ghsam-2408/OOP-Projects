public class LoanAccount extends Account {
    private double loanAmount;
    private double interestRate;


    public LoanAccount(String accountNumber, Customer accountHolder, double loanAmount, double interestRate) {
        super(accountNumber, accountHolder, 0); // Initial balance is zero for loan accounts
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.balance = loanAmount; // The loan balance is the loan amount
    }

    public void repayLoan(double amount) {
        if (amount <= balance) {
            balance -= amount;
            logTransaction("Loan Repayment", amount);
            System.out.println("Repaid " + amount + " towards loan. Remaining loan balance: " + balance);
        } else {
            System.out.println("Error: Repayment amount exceeds the outstanding loan balance.");
        }
    }

    @Override
    public void applyInterest() {
        double interest = balance * interestRate / 100;
        balance += interest;
        logTransaction("Interest Applied", interest);
        System.out.println("Applied interest of " + interest + ". New loan balance: " + balance);
    }

    @Override
    public void logTransaction(String type, double amount) {
        System.out.println("Transaction logged: " + type + " of amount " + amount);
        // Here, you can add the transaction to the bank's transaction log (not shown here)
    }

    public double getLoanAmount() {
        return loanAmount;
    }


    public double getInterestRate() {
        return interestRate;
    }
}
