public class CurrentAccount extends Account {
    private double overdraftLimit;

    // Constructor for CurrentAccount
    public CurrentAccount(String accountNumber, Customer accountHolder, double initialDeposit, double overdraftLimit) {
        super(accountNumber, accountHolder, initialDeposit);
        this.overdraftLimit = overdraftLimit;
    }

    // Override withdraw method to allow for overdraft
    @Override
    public void withdraw(double amount) {
        if (balance + overdraftLimit >= amount) {
            balance -= amount;
            logTransaction("Withdrawal", amount);
            System.out.println("Withdrew " + amount + " from current account. New balance: " + balance);
        } else {
            System.out.println("Insufficient funds, overdraft limit exceeded.");
        }
    }

    // Override applyInterest (no interest for current accounts)
    @Override
    public void applyInterest() {
        // No interest for current accounts
    }

    // Log transaction for current account
    @Override
    public void logTransaction(String type, double amount) {
        System.out.println("Transaction logged: " + type + " of amount " + amount);
        // Here, you can add the transaction to the bank's transaction log (not shown here)
    }

    // Getter for overdraft limit
    public double getOverdraftLimit() {
        return overdraftLimit;
    }

    // Setter for overdraft limit
    public void setOverdraftLimit(double overdraftLimit) {
        this.overdraftLimit = overdraftLimit;
    }
}

