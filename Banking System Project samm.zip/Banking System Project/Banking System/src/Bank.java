import java.util.ArrayList;

public class Bank implements IBank {
    private final String bankName;
    private final ArrayList<Customer> customers;
    private final ArrayList<Account> accounts;

    // Constructor
    public Bank(String bankName) {
        this.bankName = bankName;
        this.customers = new ArrayList<>();
        this.accounts = new ArrayList<>();
    }

    // Method to add a new customer to the bank
    @Override
    public void addCustomer(Customer c) {
        customers.add(c);
        System.out.println("Customer " + c.getName() + " added to the bank.");
    }

    // Method to find a customer by their ID
    public Customer findCustomerById(String customerID) {
        for (Customer customer : customers) {
            if (customer.getCustomerID().equals(customerID)) {
                return customer;
            }
        }
        System.out.println("Customer with ID " + customerID + " not found.");
        return null;
    }

    // Method to open a new account for an existing customer
    @Override
    public void openAccount(Customer c, Account a) {
        if (!customers.contains(c)) {
            System.out.println("Customer does not exist. Please add the customer first.");
            return;
        }
        accounts.add(a);
        c.openAccount(a);  // Adding the account to the customer
        System.out.println("Account " + a.getAccountNumber() + " opened for customer " + c.getName());
    }

    // Method to find an account by its account number

    public Account findAccountByNumber(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        System.out.println("Account with account number " + accountNumber + " not found.");
        return null;
    }

    // Method to calculate and apply monthly interest to savings and loan accounts

    public void calculateMonthlyInterest() {
        for (Account account : accounts) {
            if (account instanceof SavingsAccount || account instanceof LoanAccount) {
                account.applyInterest();
            }
        }
        System.out.println("Monthly interest calculated and applied.");
    }

    // Getter for the bank name
    public String getBankName() {
        return bankName;
    }

    // Getter for the list of customers
    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    // Getter for the list of accounts
    public ArrayList<Account> getAccounts() {
        return accounts;
    }
}
