public class SavingsAccount extends Account {
    private double interestRate;


    public SavingsAccount(String accountNumber, Customer accountHolder, double initialDeposit, double interestRate) {
        super(accountNumber, accountHolder, initialDeposit);
        this.interestRate = interestRate;
    }

    @Override
    public void applyInterest() {
        double interest = balance * interestRate / 100;
        balance += interest;
        logTransaction("Interest Applied", interest);
        System.out.println("Applied interest of " + interest + ". New balance: " + balance);
    }


    @Override
    public void logTransaction(String type, double amount) {
        System.out.println("Transaction logged: " + type + " of amount " + amount);
        // Here, you can add the transaction to the bank's transaction log (not shown here)
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
}

